import React from 'react';

const HelpPage = () => (
  <div>
    This is from my help component
  </div>
);

export default HelpPage;
